<?php
/*
Plugin Name:  Oculizm Tracking
Plugin URI:   https://oculizm.com 
Description:  The Wordpress plugin for tracking Oculizm activity
Version:      1.0
Author:       Oculizm
Author URI:   https://oculizm.com 
License:      Oculizm License
License URI:  https://oculizm.com
Text Domain:  oculizm
Domain Path:  /oculizm-tracking
*/


// admin actions
if (is_admin()){
    add_action('admin_menu', 'oculizm_add_menu');
    add_action('admin_init', 'oculizm_register_settings');
}


// add the admin menu item
function oculizm_add_menu() {
    add_menu_page('Oculizm', 'Oculizm', 'manage_options', 'oculizm', 'oculizm_admin_page');
}
 

 // admin page content
function oculizm_admin_page() {
    echo "<div class='wrap'>";
    echo "  <h1>Oculizm</h1>";
    echo "  <form method='post' action='options.php'>"; 

    settings_fields('oculizm-options');
    do_settings_sections('oculizm-options');

    echo "<table class='form-table'>";
    echo "    <tr valign='top'>";
    echo "    <th scope='row'>Client ID</th>";
    echo "    <td><input type='text' name='oculizm_client_id' value='" . esc_attr(get_option('oculizm_client_id')) . "' /></td>";
    echo "    </tr>";
    echo "</table>";

    submit_button();

    echo "  </form>";
    echo "</div>";
}

// register settings
function oculizm_register_settings() {
  register_setting('oculizm-options', 'oculizm_client_id');
}



// print Oculizm script and order object
add_action('wp_footer', 'oculizm_script');
function oculizm_script() {

    // get the client ID from the saved options
    $client_id = get_option('oculizm_client_id');

    // include the standard Oculizm tracking script (Javascript)
    ?>
    <script src='https://app.oculizm.com/wp-content/uploads/<?php echo $client_id; ?>_tracking.js'></script>
    <?php

    // check an order was received
    if (!is_wc_endpoint_url('order-received')) return;

    // get the order ID
    $order_id = absint(get_query_var('order-received'));

    // check it's a shop order
    if (get_post_type($order_id) !== 'shop_order') return;
    
    // get the order object
    $order = wc_get_order($order_id); 

    // check the order is being processed
    if (method_exists($order, 'has_status') && ! $order->has_status('processing')) return;

    // get the order items
    $order_items = array();
    foreach ($order->get_items() as $item_key => $item_values) {
        $item_data = $item_values->get_data();
        array_push($order_items, $item_data);
    }
    $order_items = json_encode($order_items);

    ?>
    <script id='exposeWooCommerceOrderForOculizm'>
        // print out the order and order items
        var WooCommerceOrder = <?php echo $order; ?>;
        console.log(WooCommerceOrder);
        var WooCommerceOrderItems = <?php echo $order_items; ?>;
        console.log(WooCommerceOrderItems);
    </script>
    <?php
    
}















